window.location.href = "inicial.html";
